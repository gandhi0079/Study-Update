# Study Planner Pro

Polished, offline-first student planner based on the supplied Study Planner app.

## Included
- Existing study-planner features preserved in `www/index.html`
- Dark/light theme support from the original app
- Portions, backlog, tests, stats, revision/stages and timer workflows
- PWA manifest + offline service worker
- New Study Planner Pro branding and SVG app icon
- Capacitor Android configuration for a fullscreen-style native wrapper

## Run on GitHub / locally

```bash
npm install
npm run dev
```

## Build Android APK

Install Android Studio and an Android SDK first:

```bash
npm install
npx cap add android
npm run cap:sync
npm run android
```

Then in Android Studio use **Build → Generate App Bundles or APKs → Generate APKs**.

## Important data note
The original app's client-side storage code is kept inside `www/index.html`. The Capacitor wrapper does not clear browser/WebView storage on normal app updates. If you already have data in the web version, export/backup it from the app before switching environments.
