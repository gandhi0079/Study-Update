import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.studyplannerpro.app',
  appName: 'Study Planner Pro',
  webDir: 'www',
  android: { allowMixedContent: false }
};
export default config;
